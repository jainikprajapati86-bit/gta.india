GTA INDIA — Android Studio project

This project wraps the existing HTML prototype in an Android WebView.

BUILD AN APK:
1. Install Android Studio on a computer.
2. Open this GTAIndia folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the APK location (usually app/build/outputs/apk/debug/app-debug.apk).

NOTES:
- This is a WebView wrapper around an early game prototype, not a full native 3D game.
- Internet permission is included because the prototype loads Three.js from a CDN.
- The first launch needs internet access to load the 3D engine.
